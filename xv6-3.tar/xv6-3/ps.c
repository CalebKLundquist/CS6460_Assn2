#include <stddef.h>
#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int
main(int argc, char *argv[])
{
    struct pstat pst;
    int result = getpinfo(&pst);
    if (result < 0)
    {
        printf(2, "Couldn't get pstat");
        exit();
    }
    do
    {
        printf(2, "PID TICKETS TICKS\n");
        struct pstatentry *entries = pst.proc;
        for(int i = 0; i < NPROC; i++)
        {
            if (entries[i].inuse)
            {
                printf(1, "%d %d %d\n", entries[i].pid, entries[i].tickets, entries[i].ticks);
            }
        }
        sleep(100);
        getpinfo(&pst);
    } while (argc > 1 && strcmp(argv[1], "-r") == 0);
    exit();
}
