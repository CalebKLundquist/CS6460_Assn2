#include <stddef.h>
#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
    if(argc < 3){
        printf(2, "usage: tickets num program...\n");
        exit();
    }
    int tickets = atoi(argv[1]);

    settickets(tickets);
    
    char *execargs[argc-2];
    for(int i = 0; i < argc-2; i++)
    {
        execargs[i] = argv[i+2];
    }
    execargs[argc-1] = NULL;
    exec(argv[2], execargs);
    exit();
}
