#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  // if (fork() == 0)
  //   exit2(21);
  // else
  // {
  //   int* stat = malloc(sizeof(int));
  //   wait2(stat);
  //   printf(1, "%d\n", *stat);
  // }
  printf(1, "%d\n", freemem());
  exit();
}
